import unittest
from ymap import data, ymap_proteins, ymap_genes, web

class PimpMyPackage(unittest.TestCase):
	def test_data(self):
		self.assertTrue(True)

	def test_ymap_proteins(self):
		self.assertTrue(True)

	def test_ymap_genes(self):
		self.assertTrue(True)

	def test_web(self):
		self.assertTrue(True)

if __name__ == '__main__':
	unittest.main()